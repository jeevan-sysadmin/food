export default function Page() {
  return <h1>patternanalyse!</h1>
}
